var typed = new Typed(".text", {
    Strings: ["Frontend Developer", "YouTuber" , "Web Developer"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
